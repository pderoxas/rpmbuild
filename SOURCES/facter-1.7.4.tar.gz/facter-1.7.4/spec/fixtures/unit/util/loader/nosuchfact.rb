Facter.value(:nosuchfact)
