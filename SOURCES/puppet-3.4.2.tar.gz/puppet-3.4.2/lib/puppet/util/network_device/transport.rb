require 'puppet/util/network_device'

# stub
module Puppet::Util::NetworkDevice::Transport
end
