Puppet.features.add(:msgpack, :libs => ["msgpack"])
