require 'puppet/application/face_base'

class Puppet::Application::IndirectionBase < Puppet::Application::FaceBase
end
